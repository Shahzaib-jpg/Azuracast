<?php

declare(strict_types=1);

namespace Azura\Normalizer\Exception;

class NoGetterAvailableException extends \Exception
{}
