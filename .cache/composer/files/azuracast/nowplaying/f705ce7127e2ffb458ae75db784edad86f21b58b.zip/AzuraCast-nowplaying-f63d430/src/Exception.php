<?php

declare(strict_types=1);

namespace NowPlaying;

class Exception extends \RuntimeException
{

}
