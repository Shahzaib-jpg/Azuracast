# slim-callable-eventdispatcher
Bridge code that integrates Slim's CallableResolver and Symfony's Event Dispatcher to allow resolvable event listeners.
