<?php

declare(strict_types=1);

namespace Doctrine\ORM\Exception;

use Throwable;

interface ManagerException extends Throwable
{
}
