<?php

namespace JamesHeinrich\GetID3;

class Exception extends \Exception
{
    public $message;
}
