<?php

namespace Mezzio\Session\Cache\Exception;

use Throwable;

interface ExceptionInterface extends Throwable
{
}
