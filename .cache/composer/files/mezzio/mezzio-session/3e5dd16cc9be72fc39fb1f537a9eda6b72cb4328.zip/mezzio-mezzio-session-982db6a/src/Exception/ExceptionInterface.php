<?php

declare(strict_types=1);

namespace Mezzio\Session\Exception;

/**
 * Marker interface for package exceptions.
 */
interface ExceptionInterface
{
}
