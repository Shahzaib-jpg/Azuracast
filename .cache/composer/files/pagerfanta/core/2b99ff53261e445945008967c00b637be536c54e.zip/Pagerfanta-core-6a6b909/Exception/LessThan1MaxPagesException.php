<?php

namespace Pagerfanta\Exception;

class LessThan1MaxPagesException extends NotValidMaxPerPageException
{
}
