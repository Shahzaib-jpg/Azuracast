<?php declare(strict_types=1);

namespace Pagerfanta\Exception;

class OutOfRangeCurrentPageException extends NotValidCurrentPageException
{
}
