<?php declare(strict_types=1);

namespace Pagerfanta\Exception;

/**
 * Base interface for all Pagerfanta Exceptions.
 */
interface PagerfantaException extends \Throwable
{
}
