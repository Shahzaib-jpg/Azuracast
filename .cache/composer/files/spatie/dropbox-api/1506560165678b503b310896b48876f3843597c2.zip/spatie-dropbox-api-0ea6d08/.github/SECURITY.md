# Security Policy

If you discover any security related issues, please email freek@spatie.com instead of using the issue tracker.
