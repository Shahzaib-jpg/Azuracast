# Security Policy

If you discover any security related issues, please email freek@spatie.be instead of using the issue tracker.
