CHANGELOG
=========

5.2.0
-----

 * Introduced the Beanstalkd bridge.
