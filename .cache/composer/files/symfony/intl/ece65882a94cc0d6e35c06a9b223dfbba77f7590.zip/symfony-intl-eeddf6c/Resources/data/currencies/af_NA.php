<?php

return [
    'Names' => [
        'NAD' => [
            0 => '$',
            1 => 'Namibiese dollar',
        ],
    ],
];
