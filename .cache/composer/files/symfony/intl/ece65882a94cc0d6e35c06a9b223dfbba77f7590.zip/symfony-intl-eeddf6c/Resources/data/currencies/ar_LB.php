<?php

return [
    'Names' => [
        'SDG' => [
            0 => 'SDG',
            1 => 'جنيه سوداني',
        ],
    ],
];
