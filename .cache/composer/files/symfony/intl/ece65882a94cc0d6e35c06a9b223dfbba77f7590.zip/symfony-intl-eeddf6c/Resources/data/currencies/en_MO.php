<?php

return [
    'Names' => [
        'MOP' => [
            0 => 'MOP$',
            1 => 'Macanese Pataca',
        ],
    ],
];
