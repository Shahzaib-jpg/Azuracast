<?php

return [
    'Names' => [
        'MYR' => [
            0 => 'RM',
            1 => 'Malaysian Ringgit',
        ],
    ],
];
