<?php

return [
    'Names' => [
        'COP' => [
            0 => '$',
            1 => 'peso colombiano',
        ],
        'USD' => [
            0 => 'US$',
            1 => 'dólar estadounidense',
        ],
    ],
];
