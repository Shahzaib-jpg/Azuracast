<?php

return [
    'Names' => [
        'NIO' => [
            0 => 'C$',
            1 => 'córdoba nicaragüense',
        ],
    ],
];
