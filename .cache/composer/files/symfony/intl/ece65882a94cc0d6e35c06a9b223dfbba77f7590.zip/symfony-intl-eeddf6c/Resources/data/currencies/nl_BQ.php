<?php

return [
    'Names' => [
        'USD' => [
            0 => '$',
            1 => 'Amerikaanse dollar',
        ],
    ],
];
