<?php

return [
    'Names' => [
        'MOP' => [
            0 => 'MOP$',
            1 => 'pataca macaense',
        ],
    ],
];
