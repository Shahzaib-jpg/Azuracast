<?php

return [
    'Names' => [
        'kl' => 'kalaallisut',
    ],
    'LocalizedNames' => [
    ],
];
