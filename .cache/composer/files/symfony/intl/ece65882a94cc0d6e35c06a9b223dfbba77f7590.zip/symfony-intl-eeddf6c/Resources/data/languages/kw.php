<?php

return [
    'Names' => [
        'kw' => 'kernewek',
    ],
    'LocalizedNames' => [
    ],
];
