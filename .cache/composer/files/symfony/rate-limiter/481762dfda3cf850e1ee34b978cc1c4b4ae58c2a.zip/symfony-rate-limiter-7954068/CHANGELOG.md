CHANGELOG
=========

5.4
---

 * The component is not experimental anymore
 * Add support for long intervals (months and years)

5.2.0
-----

 * added the component
