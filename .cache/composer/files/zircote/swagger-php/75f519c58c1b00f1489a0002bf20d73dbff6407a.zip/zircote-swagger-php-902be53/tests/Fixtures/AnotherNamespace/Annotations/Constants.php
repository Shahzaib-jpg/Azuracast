<?php

/**
 * @license Apache 2.0
 */

namespace AnotherNamespace\Annotations;

/**
 * @Annotation
 */
class Constants
{
    const INVALID_TIMEZONE_LOCATION = "invalidTimezoneLocation";
}