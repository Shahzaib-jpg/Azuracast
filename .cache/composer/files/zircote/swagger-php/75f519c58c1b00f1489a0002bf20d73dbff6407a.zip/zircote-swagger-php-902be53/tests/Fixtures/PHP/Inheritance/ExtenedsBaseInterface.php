<?php declare(strict_types=1);

namespace OpenApi\Tests\Fixtures\PHP\Inheritance;

interface ExtenedsBaseInterface extends BaseInterface
{

}
