<?php

namespace Foo;

class FooClass
{
}


namespace Bar;

class BarClass
{
}
