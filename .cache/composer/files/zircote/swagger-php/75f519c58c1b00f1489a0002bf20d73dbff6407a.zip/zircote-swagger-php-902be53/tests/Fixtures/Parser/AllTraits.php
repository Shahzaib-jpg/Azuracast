<?php declare(strict_types=1);

namespace OpenApi\Tests\Fixtures\Parser;

trait AllTraits
{
    use AsTrait;
    use \OpenApi\Tests\Fixtures\Parser\HelloTrait;
}
