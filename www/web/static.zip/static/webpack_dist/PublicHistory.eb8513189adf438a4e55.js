/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var PublicHistory;
/******/ (() => { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ "./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/sass-loader/dist/cjs.js!./node_modules/vue-loader/lib/index.js??vue-loader-options!./vue/components/Public/FullPlayer/SongHistory.vue?vue&type=style&index=0&lang=scss&":
/*!*********************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/sass-loader/dist/cjs.js!./node_modules/vue-loader/lib/index.js??vue-loader-options!./vue/components/Public/FullPlayer/SongHistory.vue?vue&type=style&index=0&lang=scss& ***!
  \*********************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var _node_modules_css_loader_dist_runtime_noSourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/noSourceMaps.js */ \"./node_modules/css-loader/dist/runtime/noSourceMaps.js\");\n/* harmony import */ var _node_modules_css_loader_dist_runtime_noSourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_noSourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ \"./node_modules/css-loader/dist/runtime/api.js\");\n/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);\n// Imports\n\n\nvar ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_noSourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));\n// Module\n___CSS_LOADER_EXPORT___.push([module.id, \"#station-history .song {\\n  display: flex;\\n  flex-direction: row;\\n  flex-wrap: wrap;\\n  width: 100%;\\n  line-height: normal;\\n  margin-bottom: 15px;\\n}\\n#station-history .song:last-child {\\n  margin-bottom: 0;\\n}\\n#station-history .song .order {\\n  display: flex;\\n  flex-direction: column;\\n  width: 35px;\\n  justify-content: center;\\n  margin-right: 5px;\\n  text-align: center;\\n}\\n#station-history .song .art {\\n  width: 40px;\\n  height: 40px;\\n  border-radius: 4px;\\n  margin-right: 5px;\\n}\\n#station-history .song .name {\\n  display: flex;\\n  flex: 1;\\n  flex-direction: column;\\n  justify-content: center;\\n}\\n#station-history .song .date-played {\\n  display: flex;\\n  flex-direction: column;\\n  justify-content: center;\\n  margin: 4px 0 0 40px;\\n}\\n#station-history .song .break {\\n  flex-basis: 100%;\\n  height: 0;\\n}\\n@media (min-width: 576px) {\\n#station-history .song .date-played {\\n    margin-left: auto;\\n}\\n#station-history .song .break {\\n    display: none;\\n}\\n}\", \"\"]);\n// Exports\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);\n\n\n//# sourceURL=webpack://%5Bname%5D/./vue/components/Public/FullPlayer/SongHistory.vue?./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/sass-loader/dist/cjs.js!./node_modules/vue-loader/lib/index.js??vue-loader-options");

/***/ }),

/***/ "./vue/components/Common/NowPlaying.vue":
/*!**********************************************!*\
  !*** ./vue/components/Common/NowPlaying.vue ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"nowPlayingProps\": () => (/* reexport safe */ _NowPlaying_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__.nowPlayingProps),\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var _NowPlaying_vue_vue_type_template_id_ca5d944c___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./NowPlaying.vue?vue&type=template&id=ca5d944c& */ \"./vue/components/Common/NowPlaying.vue?vue&type=template&id=ca5d944c&\");\n/* harmony import */ var _NowPlaying_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./NowPlaying.vue?vue&type=script&lang=js& */ \"./vue/components/Common/NowPlaying.vue?vue&type=script&lang=js&\");\n/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ \"./node_modules/vue-loader/lib/runtime/componentNormalizer.js\");\n\n\n\n\n\n/* normalize component */\n;\nvar component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__[\"default\"])(\n  _NowPlaying_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__[\"default\"],\n  _NowPlaying_vue_vue_type_template_id_ca5d944c___WEBPACK_IMPORTED_MODULE_0__.render,\n  _NowPlaying_vue_vue_type_template_id_ca5d944c___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,\n  false,\n  null,\n  null,\n  null\n  \n)\n\n/* hot reload */\nif (false) { var api; }\ncomponent.options.__file = \"vue/components/Common/NowPlaying.vue\"\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);\n\n//# sourceURL=webpack://%5Bname%5D/./vue/components/Common/NowPlaying.vue?");

/***/ }),

/***/ "./node_modules/vue-loader/lib/index.js??vue-loader-options!./vue/components/Common/NowPlaying.vue?vue&type=script&lang=js&":
/*!**********************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/index.js??vue-loader-options!./vue/components/Common/NowPlaying.vue?vue&type=script&lang=js& ***!
  \**********************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"nowPlayingProps\": () => (/* binding */ nowPlayingProps),\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var _components_Entity_NowPlaying__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ~/components/Entity/NowPlaying */ \"./vue/components/Entity/NowPlaying.js\");\n/* harmony import */ var nchan__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! nchan */ \"./node_modules/nchan/NchanSubscriber.js\");\n/* harmony import */ var nchan__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(nchan__WEBPACK_IMPORTED_MODULE_1__);\n//\n\n\n\n\nconst nowPlayingProps = {\n    props: {\n        nowPlayingUri: {\n            type: String,\n            required: true\n        },\n        initialNowPlaying: {\n            type: Object,\n            default () {\n                return _components_Entity_NowPlaying__WEBPACK_IMPORTED_MODULE_0__[\"default\"];\n            }\n        },\n        useNchan: {\n            type: Boolean,\n            default: true\n        }\n    }\n};\n\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({\n    mixins: [nowPlayingProps],\n    data () {\n        return {\n            'nchan_subscriber': null\n        };\n    },\n    mounted () {\n        // Convert initial NP data from prop to data.\n        this.setNowPlaying(this.initialNowPlaying);\n\n        setTimeout(this.checkNowPlaying, 5000);\n    },\n    methods: {\n        checkNowPlaying () {\n            if (this.useNchan) {\n                this.nchan_subscriber = new (nchan__WEBPACK_IMPORTED_MODULE_1___default())(this.nowPlayingUri);\n                this.nchan_subscriber.on('message', (message, message_metadata) => {\n                    let np_new = JSON.parse(message);\n                    setTimeout(() => {\n                        this.setNowPlaying(np_new);\n                    }, 5000);\n                });\n                this.nchan_subscriber.start();\n            } else {\n                this.axios.get(this.nowPlayingUri).then((response) => {\n                    this.setNowPlaying(response.data);\n\n                    setTimeout(this.checkNowPlaying, (!document.hidden) ? 15000 : 30000);\n                }).catch((error) => {\n                    setTimeout(this.checkNowPlaying, (!document.hidden) ? 30000 : 120000);\n                });\n            }\n        },\n        setNowPlaying (np_new) {\n            // Update the browser metadata for browsers that support it (i.e. Mobile Chrome)\n            if ('mediaSession' in navigator) {\n                navigator.mediaSession.metadata = new MediaMetadata({\n                    title: np_new.now_playing.song.title,\n                    artist: np_new.now_playing.song.artist,\n                    artwork: [\n                        {src: np_new.now_playing.song.art}\n                    ]\n                });\n            }\n\n            this.$emit('np_updated', np_new);\n            this.$eventHub.$emit('np_updated', np_new);\n\n            document.dispatchEvent(new CustomEvent(\"now-playing\", {\n                detail: np_new\n            }));\n        }\n    }\n});\n\n\n//# sourceURL=webpack://%5Bname%5D/./vue/components/Common/NowPlaying.vue?./node_modules/vue-loader/lib/index.js??vue-loader-options");

/***/ }),

/***/ "./vue/components/Public/FullPlayer/SongHistory.vue":
/*!**********************************************************!*\
  !*** ./vue/components/Public/FullPlayer/SongHistory.vue ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var _SongHistory_vue_vue_type_template_id_c643c0f8___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./SongHistory.vue?vue&type=template&id=c643c0f8& */ \"./vue/components/Public/FullPlayer/SongHistory.vue?vue&type=template&id=c643c0f8&\");\n/* harmony import */ var _SongHistory_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./SongHistory.vue?vue&type=script&lang=js& */ \"./vue/components/Public/FullPlayer/SongHistory.vue?vue&type=script&lang=js&\");\n/* harmony import */ var _SongHistory_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./SongHistory.vue?vue&type=style&index=0&lang=scss& */ \"./vue/components/Public/FullPlayer/SongHistory.vue?vue&type=style&index=0&lang=scss&\");\n/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ \"./node_modules/vue-loader/lib/runtime/componentNormalizer.js\");\n\n\n\n;\n\n\n/* normalize component */\n\nvar component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__[\"default\"])(\n  _SongHistory_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__[\"default\"],\n  _SongHistory_vue_vue_type_template_id_c643c0f8___WEBPACK_IMPORTED_MODULE_0__.render,\n  _SongHistory_vue_vue_type_template_id_c643c0f8___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,\n  false,\n  null,\n  null,\n  null\n  \n)\n\n/* hot reload */\nif (false) { var api; }\ncomponent.options.__file = \"vue/components/Public/FullPlayer/SongHistory.vue\"\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);\n\n//# sourceURL=webpack://%5Bname%5D/./vue/components/Public/FullPlayer/SongHistory.vue?");

/***/ }),

/***/ "./node_modules/vue-loader/lib/index.js??vue-loader-options!./vue/components/Public/FullPlayer/SongHistory.vue?vue&type=script&lang=js&":
/*!**********************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/index.js??vue-loader-options!./vue/components/Public/FullPlayer/SongHistory.vue?vue&type=script&lang=js& ***!
  \**********************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var luxon__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! luxon */ \"./node_modules/luxon/build/cjs-browser/luxon.js\");\n//\n//\n//\n//\n//\n//\n//\n//\n//\n//\n//\n//\n//\n//\n//\n//\n//\n//\n//\n//\n//\n//\n//\n//\n//\n//\n//\n//\n//\n//\n//\n//\n//\n//\n//\n//\n//\n//\n//\n//\n//\n//\n//\n//\n//\n//\n//\n//\n//\n//\n//\n//\n//\n//\n//\n//\n//\n//\n//\n//\n//\n//\n//\n//\n//\n//\n//\n//\n//\n//\n//\n//\n//\n//\n//\n//\n//\n//\n//\n\n\n\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({\n    props: {\n        history: Array,\n        showAlbumArt: {\n            type: Boolean,\n            default: true\n        },\n    },\n    computed: {\n        langNoRecords () {\n            return this.$gettext('No records to display.');\n        }\n    },\n    methods: {\n        unixTimestampToDate (timestamp) {\n            if (!timestamp) {\n                return '';\n            }\n\n            return luxon__WEBPACK_IMPORTED_MODULE_0__.DateTime.fromSeconds(timestamp).toRelative();\n        },\n        albumAndArtist (song) {\n            return [song.album, song.artist].filter(str => !!str).join(', ');\n        }\n    }\n});\n\n\n//# sourceURL=webpack://%5Bname%5D/./vue/components/Public/FullPlayer/SongHistory.vue?./node_modules/vue-loader/lib/index.js??vue-loader-options");

/***/ }),

/***/ "./vue/components/Public/History.vue":
/*!*******************************************!*\
  !*** ./vue/components/Public/History.vue ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var _History_vue_vue_type_template_id_ed2c23c0___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./History.vue?vue&type=template&id=ed2c23c0& */ \"./vue/components/Public/History.vue?vue&type=template&id=ed2c23c0&\");\n/* harmony import */ var _History_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./History.vue?vue&type=script&lang=js& */ \"./vue/components/Public/History.vue?vue&type=script&lang=js&\");\n/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ \"./node_modules/vue-loader/lib/runtime/componentNormalizer.js\");\n\n\n\n\n\n/* normalize component */\n;\nvar component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__[\"default\"])(\n  _History_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__[\"default\"],\n  _History_vue_vue_type_template_id_ed2c23c0___WEBPACK_IMPORTED_MODULE_0__.render,\n  _History_vue_vue_type_template_id_ed2c23c0___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,\n  false,\n  null,\n  null,\n  null\n  \n)\n\n/* hot reload */\nif (false) { var api; }\ncomponent.options.__file = \"vue/components/Public/History.vue\"\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);\n\n//# sourceURL=webpack://%5Bname%5D/./vue/components/Public/History.vue?");

/***/ }),

/***/ "./node_modules/vue-loader/lib/index.js??vue-loader-options!./vue/components/Public/History.vue?vue&type=script&lang=js&":
/*!*******************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/index.js??vue-loader-options!./vue/components/Public/History.vue?vue&type=script&lang=js& ***!
  \*******************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var _FullPlayer_SongHistory__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./FullPlayer/SongHistory */ \"./vue/components/Public/FullPlayer/SongHistory.vue\");\n/* harmony import */ var _components_Common_NowPlaying__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ~/components/Common/NowPlaying */ \"./vue/components/Common/NowPlaying.vue\");\n//\n//\n//\n//\n//\n//\n//\n\n\n\n\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({\n    mixins: [_components_Common_NowPlaying__WEBPACK_IMPORTED_MODULE_1__.nowPlayingProps],\n    components: {NowPlaying: _components_Common_NowPlaying__WEBPACK_IMPORTED_MODULE_1__[\"default\"], SongHistory: _FullPlayer_SongHistory__WEBPACK_IMPORTED_MODULE_0__[\"default\"]},\n    props: {\n        showAlbumArt: {\n            type: Boolean,\n            default: true\n        },\n    },\n    data() {\n        return {\n            history: []\n        };\n    },\n    methods: {\n        setNowPlaying(np) {\n            this.history = np.song_history;\n        }\n    }\n});\n\n\n//# sourceURL=webpack://%5Bname%5D/./vue/components/Public/History.vue?./node_modules/vue-loader/lib/index.js??vue-loader-options");

/***/ }),

/***/ "./vue/components/Common/NowPlaying.vue?vue&type=script&lang=js&":
/*!***********************************************************************!*\
  !*** ./vue/components/Common/NowPlaying.vue?vue&type=script&lang=js& ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__),\n/* harmony export */   \"nowPlayingProps\": () => (/* reexport safe */ _node_modules_vue_loader_lib_index_js_vue_loader_options_NowPlaying_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__.nowPlayingProps)\n/* harmony export */ });\n/* harmony import */ var _node_modules_vue_loader_lib_index_js_vue_loader_options_NowPlaying_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./NowPlaying.vue?vue&type=script&lang=js& */ \"./node_modules/vue-loader/lib/index.js??vue-loader-options!./vue/components/Common/NowPlaying.vue?vue&type=script&lang=js&\");\n /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_vue_loader_lib_index_js_vue_loader_options_NowPlaying_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__[\"default\"]); \n\n//# sourceURL=webpack://%5Bname%5D/./vue/components/Common/NowPlaying.vue?");

/***/ }),

/***/ "./vue/components/Common/NowPlaying.vue?vue&type=template&id=ca5d944c&":
/*!*****************************************************************************!*\
  !*** ./vue/components/Common/NowPlaying.vue?vue&type=template&id=ca5d944c& ***!
  \*****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"render\": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_NowPlaying_vue_vue_type_template_id_ca5d944c___WEBPACK_IMPORTED_MODULE_0__.render),\n/* harmony export */   \"staticRenderFns\": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_NowPlaying_vue_vue_type_template_id_ca5d944c___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)\n/* harmony export */ });\n/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_NowPlaying_vue_vue_type_template_id_ca5d944c___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./NowPlaying.vue?vue&type=template&id=ca5d944c& */ \"./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./vue/components/Common/NowPlaying.vue?vue&type=template&id=ca5d944c&\");\n\n\n//# sourceURL=webpack://%5Bname%5D/./vue/components/Common/NowPlaying.vue?");

/***/ }),

/***/ "./vue/components/Public/FullPlayer/SongHistory.vue?vue&type=script&lang=js&":
/*!***********************************************************************************!*\
  !*** ./vue/components/Public/FullPlayer/SongHistory.vue?vue&type=script&lang=js& ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var _node_modules_vue_loader_lib_index_js_vue_loader_options_SongHistory_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./SongHistory.vue?vue&type=script&lang=js& */ \"./node_modules/vue-loader/lib/index.js??vue-loader-options!./vue/components/Public/FullPlayer/SongHistory.vue?vue&type=script&lang=js&\");\n /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_vue_loader_lib_index_js_vue_loader_options_SongHistory_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__[\"default\"]); \n\n//# sourceURL=webpack://%5Bname%5D/./vue/components/Public/FullPlayer/SongHistory.vue?");

/***/ }),

/***/ "./vue/components/Public/FullPlayer/SongHistory.vue?vue&type=template&id=c643c0f8&":
/*!*****************************************************************************************!*\
  !*** ./vue/components/Public/FullPlayer/SongHistory.vue?vue&type=template&id=c643c0f8& ***!
  \*****************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"render\": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SongHistory_vue_vue_type_template_id_c643c0f8___WEBPACK_IMPORTED_MODULE_0__.render),\n/* harmony export */   \"staticRenderFns\": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SongHistory_vue_vue_type_template_id_c643c0f8___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)\n/* harmony export */ });\n/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SongHistory_vue_vue_type_template_id_c643c0f8___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./SongHistory.vue?vue&type=template&id=c643c0f8& */ \"./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./vue/components/Public/FullPlayer/SongHistory.vue?vue&type=template&id=c643c0f8&\");\n\n\n//# sourceURL=webpack://%5Bname%5D/./vue/components/Public/FullPlayer/SongHistory.vue?");

/***/ }),

/***/ "./vue/components/Public/History.vue?vue&type=script&lang=js&":
/*!********************************************************************!*\
  !*** ./vue/components/Public/History.vue?vue&type=script&lang=js& ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var _node_modules_vue_loader_lib_index_js_vue_loader_options_History_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./History.vue?vue&type=script&lang=js& */ \"./node_modules/vue-loader/lib/index.js??vue-loader-options!./vue/components/Public/History.vue?vue&type=script&lang=js&\");\n /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_vue_loader_lib_index_js_vue_loader_options_History_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__[\"default\"]); \n\n//# sourceURL=webpack://%5Bname%5D/./vue/components/Public/History.vue?");

/***/ }),

/***/ "./vue/components/Public/History.vue?vue&type=template&id=ed2c23c0&":
/*!**************************************************************************!*\
  !*** ./vue/components/Public/History.vue?vue&type=template&id=ed2c23c0& ***!
  \**************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"render\": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_History_vue_vue_type_template_id_ed2c23c0___WEBPACK_IMPORTED_MODULE_0__.render),\n/* harmony export */   \"staticRenderFns\": () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_History_vue_vue_type_template_id_ed2c23c0___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)\n/* harmony export */ });\n/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_History_vue_vue_type_template_id_ed2c23c0___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./History.vue?vue&type=template&id=ed2c23c0& */ \"./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./vue/components/Public/History.vue?vue&type=template&id=ed2c23c0&\");\n\n\n//# sourceURL=webpack://%5Bname%5D/./vue/components/Public/History.vue?");

/***/ }),

/***/ "./vue/components/Public/FullPlayer/SongHistory.vue?vue&type=style&index=0&lang=scss&":
/*!********************************************************************************************!*\
  !*** ./vue/components/Public/FullPlayer/SongHistory.vue?vue&type=style&index=0&lang=scss& ***!
  \********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony import */ var _node_modules_vue_style_loader_index_js_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_sass_loader_dist_cjs_js_node_modules_vue_loader_lib_index_js_vue_loader_options_SongHistory_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-style-loader/index.js!../../../../node_modules/css-loader/dist/cjs.js!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/sass-loader/dist/cjs.js!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./SongHistory.vue?vue&type=style&index=0&lang=scss& */ \"./node_modules/vue-style-loader/index.js!./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/sass-loader/dist/cjs.js!./node_modules/vue-loader/lib/index.js??vue-loader-options!./vue/components/Public/FullPlayer/SongHistory.vue?vue&type=style&index=0&lang=scss&\");\n/* harmony import */ var _node_modules_vue_style_loader_index_js_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_sass_loader_dist_cjs_js_node_modules_vue_loader_lib_index_js_vue_loader_options_SongHistory_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_vue_style_loader_index_js_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_sass_loader_dist_cjs_js_node_modules_vue_loader_lib_index_js_vue_loader_options_SongHistory_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0__);\n/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};\n/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in _node_modules_vue_style_loader_index_js_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_sass_loader_dist_cjs_js_node_modules_vue_loader_lib_index_js_vue_loader_options_SongHistory_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0__) if(__WEBPACK_IMPORT_KEY__ !== \"default\") __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => _node_modules_vue_style_loader_index_js_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_sass_loader_dist_cjs_js_node_modules_vue_loader_lib_index_js_vue_loader_options_SongHistory_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0__[__WEBPACK_IMPORT_KEY__]\n/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);\n\n\n//# sourceURL=webpack://%5Bname%5D/./vue/components/Public/FullPlayer/SongHistory.vue?");

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./vue/components/Common/NowPlaying.vue?vue&type=template&id=ca5d944c&":
/*!********************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./vue/components/Common/NowPlaying.vue?vue&type=template&id=ca5d944c& ***!
  \********************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"render\": () => (/* binding */ render),\n/* harmony export */   \"staticRenderFns\": () => (/* binding */ staticRenderFns)\n/* harmony export */ });\nvar render = function () {\n  var _vm = this\n  var _h = _vm.$createElement\n  var _c = _vm._self._c || _h\n  return _c(\"div\")\n}\nvar staticRenderFns = []\nrender._withStripped = true\n\n\n\n//# sourceURL=webpack://%5Bname%5D/./vue/components/Common/NowPlaying.vue?./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options");

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./vue/components/Public/FullPlayer/SongHistory.vue?vue&type=template&id=c643c0f8&":
/*!********************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./vue/components/Public/FullPlayer/SongHistory.vue?vue&type=template&id=c643c0f8& ***!
  \********************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"render\": () => (/* binding */ render),\n/* harmony export */   \"staticRenderFns\": () => (/* binding */ staticRenderFns)\n/* harmony export */ });\nvar render = function () {\n  var _vm = this\n  var _h = _vm.$createElement\n  var _c = _vm._self._c || _h\n  return _c(\n    \"div\",\n    { attrs: { id: \"station-history\" } },\n    [\n      _vm.history.length <= 0\n        ? _c(\"p\", [_vm._v(_vm._s(_vm.langNoRecords))])\n        : _vm._e(),\n      _vm._v(\" \"),\n      _vm._l(_vm.history, function (row, index) {\n        return _c(\"div\", { staticClass: \"song\" }, [\n          _c(\"strong\", { staticClass: \"order\" }, [\n            _vm._v(_vm._s(_vm.history.length - index)),\n          ]),\n          _vm._v(\" \"),\n          _vm.showAlbumArt\n            ? _c(\"img\", { staticClass: \"art\", attrs: { src: row.song.art } })\n            : _vm._e(),\n          _vm._v(\" \"),\n          _c(\"div\", { staticClass: \"name\" }, [\n            _c(\"strong\", { domProps: { innerHTML: _vm._s(row.song.title) } }),\n            _vm._v(\" \"),\n            _c(\"span\", {\n              domProps: { innerHTML: _vm._s(_vm.albumAndArtist(row.song)) },\n            }),\n          ]),\n          _vm._v(\" \"),\n          _c(\"div\", { staticClass: \"break\" }),\n          _vm._v(\" \"),\n          _c(\"small\", { staticClass: \"date-played text-muted\" }, [\n            _c(\n              \"span\",\n              {\n                domProps: {\n                  innerHTML: _vm._s(_vm.unixTimestampToDate(row.played_at)),\n                },\n              },\n              [_vm._v(_vm._s(row.played_at))]\n            ),\n          ]),\n        ])\n      }),\n    ],\n    2\n  )\n}\nvar staticRenderFns = []\nrender._withStripped = true\n\n\n\n//# sourceURL=webpack://%5Bname%5D/./vue/components/Public/FullPlayer/SongHistory.vue?./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options");

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./vue/components/Public/History.vue?vue&type=template&id=ed2c23c0&":
/*!*****************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./vue/components/Public/History.vue?vue&type=template&id=ed2c23c0& ***!
  \*****************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"render\": () => (/* binding */ render),\n/* harmony export */   \"staticRenderFns\": () => (/* binding */ staticRenderFns)\n/* harmony export */ });\nvar render = function () {\n  var _vm = this\n  var _h = _vm.$createElement\n  var _c = _vm._self._c || _h\n  return _c(\n    \"div\",\n    { attrs: { id: \"song_history\" } },\n    [\n      _c(\n        \"now-playing\",\n        _vm._b(\n          { on: { np_updated: _vm.setNowPlaying } },\n          \"now-playing\",\n          _vm.$props,\n          false\n        )\n      ),\n      _vm._v(\" \"),\n      _c(\"song-history\", {\n        attrs: { \"show-album-art\": _vm.showAlbumArt, history: _vm.history },\n      }),\n    ],\n    1\n  )\n}\nvar staticRenderFns = []\nrender._withStripped = true\n\n\n\n//# sourceURL=webpack://%5Bname%5D/./vue/components/Public/History.vue?./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options");

/***/ }),

/***/ "./node_modules/vue-style-loader/index.js!./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/sass-loader/dist/cjs.js!./node_modules/vue-loader/lib/index.js??vue-loader-options!./vue/components/Public/FullPlayer/SongHistory.vue?vue&type=style&index=0&lang=scss&":
/*!**************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-style-loader/index.js!./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/sass-loader/dist/cjs.js!./node_modules/vue-loader/lib/index.js??vue-loader-options!./vue/components/Public/FullPlayer/SongHistory.vue?vue&type=style&index=0&lang=scss& ***!
  \**************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

eval("// style-loader: Adds some css to the DOM by adding a <style> tag\n\n// load the styles\nvar content = __webpack_require__(/*! !!../../../../node_modules/css-loader/dist/cjs.js!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/sass-loader/dist/cjs.js!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./SongHistory.vue?vue&type=style&index=0&lang=scss& */ \"./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/sass-loader/dist/cjs.js!./node_modules/vue-loader/lib/index.js??vue-loader-options!./vue/components/Public/FullPlayer/SongHistory.vue?vue&type=style&index=0&lang=scss&\");\nif(content.__esModule) content = content.default;\nif(typeof content === 'string') content = [[module.id, content, '']];\nif(content.locals) module.exports = content.locals;\n// add the styles to the DOM\nvar add = __webpack_require__(/*! !../../../../node_modules/vue-style-loader/lib/addStylesClient.js */ \"./node_modules/vue-style-loader/lib/addStylesClient.js\")[\"default\"]\nvar update = add(\"4e7a85e0\", content, false, {});\n// Hot Module Replacement\nif(false) {}\n\n//# sourceURL=webpack://%5Bname%5D/./vue/components/Public/FullPlayer/SongHistory.vue?./node_modules/vue-style-loader/index.js!./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/sass-loader/dist/cjs.js!./node_modules/vue-loader/lib/index.js??vue-loader-options");

/***/ }),

/***/ "./vue/base.js":
/*!*********************!*\
  !*** ./vue/base.js ***!
  \*********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* export default binding */ __WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! vue */ \"./node_modules/vue/dist/vue.runtime.esm.js\");\n/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! axios */ \"./node_modules/axios/index.js\");\n/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var vue_axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vue-axios */ \"./node_modules/vue-axios/dist/vue-axios.esm.min.js\");\n/* harmony import */ var vue_gettext__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! vue-gettext */ \"./node_modules/vue-gettext/dist/vue-gettext.js\");\n/* harmony import */ var vue_gettext__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(vue_gettext__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var _resources_locale_translations_json__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../resources/locale/translations.json */ \"../resources/locale/translations.json\");\n\n\n\n\n\n\ndocument.addEventListener('DOMContentLoaded', function () {\n  // Configure localization\n  vue__WEBPACK_IMPORTED_MODULE_4__[\"default\"].use((vue_gettext__WEBPACK_IMPORTED_MODULE_2___default()), {\n    defaultLanguage: 'en_US',\n    translations: _resources_locale_translations_json__WEBPACK_IMPORTED_MODULE_3__,\n    silent: true\n  });\n\n  if (typeof App.locale !== 'undefined') {\n    vue__WEBPACK_IMPORTED_MODULE_4__[\"default\"].config.language = App.locale;\n  }\n\n  // Configure auto-CSRF on requests\n  if (typeof App.api_csrf !== 'undefined') {\n    (axios__WEBPACK_IMPORTED_MODULE_0___default().defaults.headers.common[\"X-API-CSRF\"]) = App.api_csrf;\n  }\n\n  vue__WEBPACK_IMPORTED_MODULE_4__[\"default\"].use(vue_axios__WEBPACK_IMPORTED_MODULE_1__[\"default\"], (axios__WEBPACK_IMPORTED_MODULE_0___default()));\n\n  vue__WEBPACK_IMPORTED_MODULE_4__[\"default\"].prototype.$eventHub = new vue__WEBPACK_IMPORTED_MODULE_4__[\"default\"]();\n});\n\n/* harmony default export */ function __WEBPACK_DEFAULT_EXPORT__(component) {\n  return function (el, props) {\n    return new vue__WEBPACK_IMPORTED_MODULE_4__[\"default\"]({\n      el: el,\n      created () {\n        let handleAxiosError = (error) => {\n          let notifyMessage = this.$gettext('An error occurred and your request could not be completed.');\n          if (error.response) {\n            // Request made and server responded\n            notifyMessage = error.response.data.message;\n            console.error(notifyMessage);\n          } else if (error.request) {\n            // The request was made but no response was received\n            console.error(error.request);\n          } else {\n            // Something happened in setting up the request that triggered an Error\n            console.error('Error', error.message);\n          }\n\n          if (typeof this.$notifyError === 'function') {\n            this.$notifyError(notifyMessage);\n          }\n        };\n\n        axios__WEBPACK_IMPORTED_MODULE_0___default().interceptors.request.use((config) => {\n          return config;\n        }, (error) => {\n          handleAxiosError(error);\n          return Promise.reject(error);\n        });\n\n        axios__WEBPACK_IMPORTED_MODULE_0___default().interceptors.response.use((response) => {\n          return response;\n        }, (error) => {\n          handleAxiosError(error);\n          return Promise.reject(error);\n        });\n      },\n      render: createElement => createElement(component, { props: props })\n    });\n  };\n}\n\n\n//# sourceURL=webpack://%5Bname%5D/./vue/base.js?");

/***/ }),

/***/ "./vue/components/Entity/NowPlaying.js":
/*!*********************************************!*\
  !*** ./vue/components/Entity/NowPlaying.js ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({\n  'station': {\n    'id': 1,\n    'name': 'Station Name',\n    'shortcode': 'station_name',\n    'description': 'Station Description.',\n    'frontend': 'icecast',\n    'backend': 'liquidsoap',\n    'listen_url': '',\n    'url': '',\n    'playlist_pls_url': '',\n    'playlist_m3u_url': '',\n    'is_public': true,\n    'mounts': [],\n    'remotes': []\n  },\n  'listeners': {\n    'current': 0,\n    'unique': 0,\n    'total': 0\n  },\n  'live': {\n    'is_live': false,\n    'streamer_name': '',\n    'broadcast_start': null\n  },\n  'now_playing': {\n    'elapsed': 0,\n    'remaining': 0,\n    'sh_id': 0,\n    'played_at': 0,\n    'duration': 0,\n    'playlist': 'default',\n    'streamer': '',\n    'is_request': false,\n    'song': {\n      'id': '',\n      'text': '',\n      'artist': '',\n      'title': '',\n      'album': '',\n      'genre': '',\n      'lyrics': '',\n      'art': '',\n      'custom_fields': {}\n    }\n  },\n  'playing_next': {\n    'cued_at': 0,\n    'duration': 0,\n    'playlist': 'default',\n    'is_request': false,\n    'song': {\n      'id': '',\n      'text': '',\n      'artist': '',\n      'title': '',\n      'album': '',\n      'genre': '',\n      'lyrics': '',\n      'art': '',\n      'custom_fields': {}\n    }\n  },\n  'song_history': []\n});\n\n\n//# sourceURL=webpack://%5Bname%5D/./vue/components/Entity/NowPlaying.js?");

/***/ }),

/***/ "./vue/pages/Public/History.js":
/*!*************************************!*\
  !*** ./vue/pages/Public/History.js ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var _base_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ~/base.js */ \"./vue/base.js\");\n/* harmony import */ var _vendor_luxon_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ~/vendor/luxon.js */ \"./vue/vendor/luxon.js\");\n/* harmony import */ var _components_Public_History_vue__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ~/components/Public/History.vue */ \"./vue/components/Public/History.vue\");\n\n\n\n\n\n\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,_base_js__WEBPACK_IMPORTED_MODULE_0__[\"default\"])(_components_Public_History_vue__WEBPACK_IMPORTED_MODULE_2__[\"default\"]));\n\n\n//# sourceURL=webpack://%5Bname%5D/./vue/pages/Public/History.js?");

/***/ }),

/***/ "./vue/vendor/luxon.js":
/*!*****************************!*\
  !*** ./vue/vendor/luxon.js ***!
  \*****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony import */ var luxon__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! luxon */ \"./node_modules/luxon/build/cjs-browser/luxon.js\");\n\n\ndocument.addEventListener('DOMContentLoaded', function () {\n  luxon__WEBPACK_IMPORTED_MODULE_0__.Settings.defaultLocale = App.locale_with_dashes;\n\n  luxon__WEBPACK_IMPORTED_MODULE_0__.Settings.defaultZoneName = 'UTC';\n});\n\n\n//# sourceURL=webpack://%5Bname%5D/./vue/vendor/luxon.js?");

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			id: moduleId,
/******/ 			loaded: false,
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Flag the module as loaded
/******/ 		module.loaded = true;
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = __webpack_modules__;
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/amd options */
/******/ 	(() => {
/******/ 		__webpack_require__.amdO = {};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/chunk loaded */
/******/ 	(() => {
/******/ 		var deferred = [];
/******/ 		__webpack_require__.O = (result, chunkIds, fn, priority) => {
/******/ 			if(chunkIds) {
/******/ 				priority = priority || 0;
/******/ 				for(var i = deferred.length; i > 0 && deferred[i - 1][2] > priority; i--) deferred[i] = deferred[i - 1];
/******/ 				deferred[i] = [chunkIds, fn, priority];
/******/ 				return;
/******/ 			}
/******/ 			var notFulfilled = Infinity;
/******/ 			for (var i = 0; i < deferred.length; i++) {
/******/ 				var [chunkIds, fn, priority] = deferred[i];
/******/ 				var fulfilled = true;
/******/ 				for (var j = 0; j < chunkIds.length; j++) {
/******/ 					if ((priority & 1 === 0 || notFulfilled >= priority) && Object.keys(__webpack_require__.O).every((key) => (__webpack_require__.O[key](chunkIds[j])))) {
/******/ 						chunkIds.splice(j--, 1);
/******/ 					} else {
/******/ 						fulfilled = false;
/******/ 						if(priority < notFulfilled) notFulfilled = priority;
/******/ 					}
/******/ 				}
/******/ 				if(fulfilled) {
/******/ 					deferred.splice(i--, 1)
/******/ 					var r = fn();
/******/ 					if (r !== undefined) result = r;
/******/ 				}
/******/ 			}
/******/ 			return result;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/global */
/******/ 	(() => {
/******/ 		__webpack_require__.g = (function() {
/******/ 			if (typeof globalThis === 'object') return globalThis;
/******/ 			try {
/******/ 				return this || new Function('return this')();
/******/ 			} catch (e) {
/******/ 				if (typeof window === 'object') return window;
/******/ 			}
/******/ 		})();
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/harmony module decorator */
/******/ 	(() => {
/******/ 		__webpack_require__.hmd = (module) => {
/******/ 			module = Object.create(module);
/******/ 			if (!module.children) module.children = [];
/******/ 			Object.defineProperty(module, 'exports', {
/******/ 				enumerable: true,
/******/ 				set: () => {
/******/ 					throw new Error('ES Modules may not assign module.exports or exports.*, Use ESM export syntax, instead: ' + module.id);
/******/ 				}
/******/ 			});
/******/ 			return module;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/node module decorator */
/******/ 	(() => {
/******/ 		__webpack_require__.nmd = (module) => {
/******/ 			module.paths = [];
/******/ 			if (!module.children) module.children = [];
/******/ 			return module;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/jsonp chunk loading */
/******/ 	(() => {
/******/ 		// no baseURI
/******/ 		
/******/ 		// object to store loaded and loading chunks
/******/ 		// undefined = chunk not loaded, null = chunk preloaded/prefetched
/******/ 		// [resolve, reject, Promise] = chunk loading, 0 = chunk loaded
/******/ 		var installedChunks = {
/******/ 			"PublicHistory": 0
/******/ 		};
/******/ 		
/******/ 		// no chunk on demand loading
/******/ 		
/******/ 		// no prefetching
/******/ 		
/******/ 		// no preloaded
/******/ 		
/******/ 		// no HMR
/******/ 		
/******/ 		// no HMR manifest
/******/ 		
/******/ 		__webpack_require__.O.j = (chunkId) => (installedChunks[chunkId] === 0);
/******/ 		
/******/ 		// install a JSONP callback for chunk loading
/******/ 		var webpackJsonpCallback = (parentChunkLoadingFunction, data) => {
/******/ 			var [chunkIds, moreModules, runtime] = data;
/******/ 			// add "moreModules" to the modules object,
/******/ 			// then flag all "chunkIds" as loaded and fire callback
/******/ 			var moduleId, chunkId, i = 0;
/******/ 			if(chunkIds.some((id) => (installedChunks[id] !== 0))) {
/******/ 				for(moduleId in moreModules) {
/******/ 					if(__webpack_require__.o(moreModules, moduleId)) {
/******/ 						__webpack_require__.m[moduleId] = moreModules[moduleId];
/******/ 					}
/******/ 				}
/******/ 				if(runtime) var result = runtime(__webpack_require__);
/******/ 			}
/******/ 			if(parentChunkLoadingFunction) parentChunkLoadingFunction(data);
/******/ 			for(;i < chunkIds.length; i++) {
/******/ 				chunkId = chunkIds[i];
/******/ 				if(__webpack_require__.o(installedChunks, chunkId) && installedChunks[chunkId]) {
/******/ 					installedChunks[chunkId][0]();
/******/ 				}
/******/ 				installedChunks[chunkIds[i]] = 0;
/******/ 			}
/******/ 			return __webpack_require__.O(result);
/******/ 		}
/******/ 		
/******/ 		var chunkLoadingGlobal = self["webpackChunk_name_"] = self["webpackChunk_name_"] || [];
/******/ 		chunkLoadingGlobal.forEach(webpackJsonpCallback.bind(null, 0));
/******/ 		chunkLoadingGlobal.push = webpackJsonpCallback.bind(null, chunkLoadingGlobal.push.bind(chunkLoadingGlobal));
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module depends on other loaded chunks and execution need to be delayed
/******/ 	var __webpack_exports__ = __webpack_require__.O(undefined, ["translations","vendor-vue","vendor-axios","vendor-vue-gettext","vendor-vue-style-loader","vendor-css-loader","vendor-vue-loader","vendor-vue-axios","vendor-luxon","vendor-nchan"], () => (__webpack_require__("./vue/pages/Public/History.js")))
/******/ 	__webpack_exports__ = __webpack_require__.O(__webpack_exports__);
/******/ 	PublicHistory = __webpack_exports__;
/******/ 	
/******/ })()
;